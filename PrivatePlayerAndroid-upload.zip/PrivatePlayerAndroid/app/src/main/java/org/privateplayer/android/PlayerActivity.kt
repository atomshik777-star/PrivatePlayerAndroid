package org.privateplayer.android

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import java.io.File
import java.util.Locale

/** Private Player starter with common Android intents, optional HTTP headers and external subtitles. */
class PlayerActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hideSystemUi()
        playerView = PlayerView(this).apply {
            useController = true
            keepScreenOn = true
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        }
        setContentView(playerView)
        playIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        playIntent(intent)
    }

    private fun hideSystemUi() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }

    private fun playIntent(intent: Intent?) {
        if (intent == null) return
        val uri = intent.data
            ?: intent.getParcelableExtraCompatUri("android.intent.extra.STREAM")
            ?: findUriExtra(intent)
        if (uri == null) {
            if (player == null) initializePlayer(emptyMap())
            return
        }

        val headers = readHeaders(intent)
        releasePlayer()
        initializePlayer(headers)

        val itemBuilder = MediaItem.Builder().setUri(uri)
        val mime = intent.type
        if (!mime.isNullOrBlank()) itemBuilder.setMimeType(mime)

        val subtitleUri = findSubtitleUri(intent)
        if (subtitleUri != null) {
            val subtitleMime = subtitleMimeType(subtitleUri, intent)
            itemBuilder.setSubtitleConfigurations(
                listOf(
                    MediaItem.SubtitleConfiguration.Builder(subtitleUri)
                        .setMimeType(subtitleMime)
                        .setLanguage(intent.getStringExtra("subtitle_language") ?: "und")
                        .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                        .build()
                )
            )
        }

        val positionMs = readPosition(intent)
        player?.apply {
            setMediaItem(itemBuilder.build())
            prepare()
            if (positionMs > 0L) seekTo(positionMs)
            playWhenReady = true
        }
    }

    private fun initializePlayer(headers: Map<String, String>) {
        val httpFactory = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setDefaultRequestProperties(headers)
        val dataSourceFactory = DefaultDataSource.Factory(this, httpFactory)
        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .build()
            .also { exo ->
                playerView.player = exo
                exo.addListener(object : Player.Listener {
                    override fun onPlayerError(error: PlaybackException) {
                        Toast.makeText(
                            this@PlayerActivity,
                            "Не удалось воспроизвести файл: ${error.errorCodeName}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                })
            }
    }

    private fun readHeaders(intent: Intent): Map<String, String> {
        val result = linkedMapOf<String, String>()
        // Supported conventions used by some external player integrations.
        for (key in listOf("headers", "http_headers", "extra_headers")) {
            val bundle = intent.getBundleExtra(key) ?: continue
            for (name in bundle.keySet()) {
                val value = bundle.get(name)?.toString()?.trim().orEmpty()
                if (name.isNotBlank() && value.isNotBlank()) result[name] = value
            }
        }
        // A single Referer is also accepted as a simple fallback.
        intent.getStringExtra("referer")?.takeIf { it.isNotBlank() }?.let {
            result.putIfAbsent("Referer", it)
        }
        return result
    }

    private fun findUriExtra(intent: Intent): Uri? {
        val keys = listOf("url", "video_url", "videoUrl", "uri", "path", "file")
        for (key in keys) {
            val value = intent.getStringExtra(key)?.trim().orEmpty()
            if (value.isNotEmpty()) {
                val parsed = Uri.parse(value)
                return if (parsed.scheme != null) parsed else Uri.fromFile(File(value))
            }
        }
        return null
    }

    private fun findSubtitleUri(intent: Intent): Uri? {
        val keys = listOf("subtitle", "subtitle_url", "subtitleUrl", "subtitles", "srt")
        for (key in keys) {
            val value = intent.getStringExtra(key)?.trim().orEmpty()
            if (value.isNotEmpty()) {
                val parsed = Uri.parse(value)
                return if (parsed.scheme != null) parsed else Uri.fromFile(File(value))
            }
        }
        return null
    }

    private fun subtitleMimeType(uri: Uri, intent: Intent): String {
        val explicit = intent.getStringExtra("subtitle_mime_type")
        if (!explicit.isNullOrBlank()) return explicit
        return when (uri.lastPathSegment.orEmpty().substringAfterLast('.', "").lowercase(Locale.ROOT)) {
            "srt" -> MimeTypes.APPLICATION_SUBRIP
            "vtt" -> MimeTypes.TEXT_VTT
            "ssa", "ass" -> MimeTypes.TEXT_SSA
            "ttml", "xml" -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP
        }
    }

    private fun readPosition(intent: Intent): Long {
        for (key in listOf("position_ms", "start_position", "resume_position", "position")) {
            val value = intent.getLongExtra(key, -1L)
            if (value >= 0L) return value
            val stringValue = intent.getStringExtra(key)?.toLongOrNull()
            if (stringValue != null && stringValue >= 0L) return stringValue
        }
        return 0L
    }

    private fun releasePlayer() {
        playerView.player = null
        player?.release()
        player = null
    }

    @Suppress("DEPRECATION")
    private fun Intent.getParcelableExtraCompatUri(key: String): Uri? =
        getParcelableExtra(key) as? Uri

    override fun onDestroy() {
        releasePlayer()
        super.onDestroy()
    }
}
