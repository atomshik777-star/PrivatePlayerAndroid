# Private Player — Android starter (stage 2)

Private Player is a Kotlin/AndroidX Media3 starter for phones and tablets, with Android TV support in the manifest. This is source code, not a prebuilt APK.

## Added in stage 2

- Common `ACTION_VIEW` and `ACTION_SEND` URI handling.
- URL extras: `url`, `video_url`, `videoUrl`, `uri`, `path`, `file`.
- Resume-position extras: `position_ms`, `start_position`, `resume_position`, `position`.
- Optional HTTP headers in a `Bundle` extra named `headers`, `http_headers`, or `extra_headers`; optional `referer` string.
- Optional subtitle URI extras: `subtitle`, `subtitle_url`, `subtitleUrl`, `subtitles`, `srt`.
- GitHub Actions workflow to build a debug APK in the cloud, so a computer is not strictly necessary if you can use GitHub in your phone browser.

## Build without a computer (phone-only route)

1. Download this ZIP to your phone and extract it with a file manager.
2. In a browser, sign in to GitHub and create a new repository.
3. Upload the extracted project files and folders to the repository (keep the `.github/workflows/build-apk.yml` file; if the mobile web UI cannot upload folders, use GitHub's web editor or a Git client app that supports folder uploads).
4. Open the repository's **Actions** tab and run **Build Private Player APK**. Approve Actions if GitHub asks.
5. When the workflow completes successfully, open the run and download the `PrivatePlayer-debug-apk` artifact. Extract the artifact ZIP; it contains `app-debug.apk`.
6. Open the APK on the phone and allow installation from that source if Android asks. Only install APKs you built from your own repository.

The workflow runs on GitHub-hosted infrastructure. You will need a GitHub account and internet access. UI labels can vary by locale/device.

## Build with Android Studio

- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Android SDK Platform 35

Open the project directory and run `gradle assembleDebug` or use Android Studio's Gradle sync/build controls.

## Integration notes

The app handles common Android intents and a few conventional extras, but that does **not** guarantee compatibility with every Lampa, HD VideoBox, or MX Player integration. Different apps use different extra names, URI permission rules, result contracts, and sometimes hard-coded package checks. Do not impersonate MX Player's package name or signature.

## Playback and privacy limitations

- Media3 supports many common formats, but actual codecs and containers depend on Android/device capabilities. FFmpeg is not included yet.
- HTTP headers are read from a `Bundle` of string values. Other header representations may need adapters.
- Subtitle support is best-effort for common SRT/VTT/ASS/TTML types; external subtitle access depends on the URI permissions and stream format.
- The app requests INTERNET for network playback and does not include ad or analytics SDKs. Network playback necessarily contacts the stream host; this is not an offline-only app.
- This starter has not yet been built or tested against physical devices in this workspace. The cloud workflow must complete successfully before treating an APK as build-verified.
